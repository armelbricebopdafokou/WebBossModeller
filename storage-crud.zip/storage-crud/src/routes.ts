import { Router } from 'express';
import minioClient from './minioClient';
import { Request, Response } from 'express';

const router = Router();
const bucketName = process.env.MINIO_BUCKET_NAME!;

// Create object
router.post('/upload', async (req: Request, res: Response) => {
    const { objectName, objectContent } = req.body;

    try {
        await minioClient.putObject(bucketName, objectName, objectContent);
        res.status(201).send('Object uploaded successfully');
    } catch (error) {
        res.status(500).send(error);
    }
});

// Read object
router.get('/download/:objectName', async (req: Request, res: Response) => {
    const { objectName } = req.params;

    try {
        const dataStream = await minioClient.getObject(bucketName, objectName);
        dataStream.pipe(res);
    } catch (error) {
        console.log(error);
        res.status(500).send(error);
    }
});

// List objects
router.get('/list/:prefix?', async (req: Request, res: Response) => {
    const prefix = req.params.prefix || '';

    try {
        const objectsList: any[] = [];
        const stream = minioClient.listObjectsV2(bucketName, prefix, true);

        stream.on('data', obj => {
            objectsList.push(obj);
        });

        stream.on('end', () => {
            res.json(objectsList);
        });

        stream.on('error', (error) => {
            res.status(500).send(error);
        });
    } catch (error) {
        res.status(500).send(error);
    }
});


// Update object
router.put('/update/:objectName', async (req: Request, res: Response) => {
    const { objectName } = req.params;
    const { newObjectContent } = req.body;

    try {
        await minioClient.putObject(bucketName, objectName, newObjectContent);
        res.status(200).send('Object updated successfully');
    } catch (error) {
        res.status(500).send(error);
    }
});

// Delete object
router.delete('/delete/:objectName', async (req: Request, res: Response) => {
    const { objectName } = req.params;

    try {
        await minioClient.removeObject(bucketName, objectName);
        res.status(200).send('Object deleted successfully');
    } catch (error) {
        res.status(500).send(error);
    }
});

export default router;
