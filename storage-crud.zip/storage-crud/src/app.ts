import express from 'express';
import bodyParser from 'body-parser';
import routes from './routes';
import { logRequest } from './logger';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = process.env.PORT || 6600;

app.use(bodyParser.json());
app.use('/', logRequest, routes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
