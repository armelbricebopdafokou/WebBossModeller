import { Request, Response, NextFunction } from 'express';

export async function logRequest(req: Request, res: Response, next: NextFunction) {
    const data = { url: req.originalUrl, body: req.body, headers: req.rawHeaders };
    console.log("request was made to:", data.url)
    //console.log("request came in with username",req.body.username);
    //console.log("request came in with password",req.body.password);
    next();
}