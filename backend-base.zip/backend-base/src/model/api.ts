export interface api {
    name: String;
    keyhash: String;
    username?: String;
    uid?: number;
}